const express=require('express');
const router=express.Router();
const pool=require('../pool.js');

router.post('/log',(req,res)=>{
    var name=req.body.uname;
    var pwd=req.body.upwd;
    var sql='select id from app_user where name=? and pwd=?'
    pool.query(sql,[name,pwd],(err,result)=>{
        if(err) throw err;
        res.send(result);

    })
})
router.get('/sure',(req,res)=>{
   var name=req.query.name;
    var sql='select count(id) num from app_user where name=?'
   pool.query(sql,[name],(err,result)=>{
      if(err) throw err;
      res.send(result);
   })
})
router.post('/submit',(req,res)=>{
   var name=req.body.name;
   var pwd=req.body.pwd;
  var sql='insert into app_user values(null,?,?)'
  pool.query(sql,[name,pwd],(err,result)=>{
      if(result.affectedRows>0){
          res.send({msg:1})
      }else{
        res.send({msg:0})
      }
  })
})
module.exports=router;
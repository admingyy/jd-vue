const express=require('express');
const router=express.Router();
const pool=require('../pool');
 /*   res.writeHead(200,{
            'Content-Type':'application/json,charset=utf-8',
            'Access-Control-Allow-Origin':'*'
        })
       // res.setHeader("Access-Control-Allow-Origin","*");
        res.write(JSON.stringify(obj));
          res.end(); */

router.get('/swipe',(req,res)=>{
    var obj=['http://127.0.0.1:3000/swipe-table/1.jpg','http://127.0.0.1:3000/swipe-table/2.jpg','http://127.0.0.1:3000/swipe-table/3.jpg','http://127.0.0.1:3000/swipe-table/4.jpg',
    'http://127.0.0.1:3000/swipe-table/5.jpg'
];
      res.send(obj);
    })
router.get('/gif',(req,res)=>{
var obj=['http://127.0.0.1:3000/gif/gif.gif']
  res.send(obj)
})

router.get('/nav',(req,res)=>{
var obj=[{url:'http://127.0.0.1:3000/nav/nav1.png',name:'京东超市'},{url:'http://127.0.0.1:3000/nav/nav2.png',name:'全球购'},{url:'http://127.0.0.1:3000/nav/nav3.png',name:'京东时尚'},{url:'http://127.0.0.1:3000/nav/nav4.png',name:'京东生鲜'},{url:'http://127.0.0.1:3000/nav/nav5.png',name:'京东到家'},{url:'http://127.0.0.1:3000/nav/nav6.png',name:'充值缴费'},{url:'http://127.0.0.1:3000/nav/nav7.png',name:'9.9元拼'},{url:'http://127.0.0.1:3000/nav/nav8.png',name:'领券'},{url:'http://127.0.0.1:3000/nav/nav9.png',name:'赚钱'},{url:'http://127.0.0.1:3000/nav/nav10.png',name:'全部'},]
   res.send(obj)    
})


//ul轮播广告
router.get('/change',(req,res)=>{
    var obj=['小宝宝口腔清洁这样做，爸妈千万别糊弄','吉利“换标”后又火了！新车被18个国家看上，订单破7万','拒绝花架子，实力与颜值俱全的男士手表','精品纯棉袜子，展现不一样的男士风度'];
    res.send(obj);
})

router.get('/content',(req,res)=>{
    var obj=['http://127.0.0.1:3000/content/content1.jpg','http://127.0.0.1:3000/content/content2.jpg','http://127.0.0.1:3000/content/content3.jpg'];
    res.send(obj);
})


router.get('/st',(req,res)=>{
  var obj=[{id:1,url:'http://127.0.0.1:3000/sou/s1.jpg',oldprice:120,newprice:55},
  {id:2,url:'http://127.0.0.1:3000/sou/s2.jpg',oldprice:128,newprice:35},
  {id:3,url:'http://127.0.0.1:3000/sou/s3.jpg',oldprice:12,newprice:5},
  {id:4,url:'http://127.0.0.1:3000/sou/s5.jpg',oldprice:802,newprice:505},
  {id:5,url:'http://127.0.0.1:3000/sou/s6.jpg',oldprice:28,newprice:52},
  {id:6,url:'http://127.0.0.1:3000/sou/s7.jpg',oldprice:68,newprice:34},
  {id:7,url:'http://127.0.0.1:3000/sou/s8.jpg',oldprice:98,newprice:66}]
   res.send(obj)
})

router.get('/store',(req,res)=>{
var obj=[[{id:1,url:'http://127.0.0.1:3000/sc/sc1.jpg',info:'母婴馆',sale:'超值拼团'},
          {id:2,url:'http://127.0.0.1:3000/sc/sc2.jpg',info:'美食城',sale:'低至五折'},
          {id:3,url:'http://127.0.0.1:3000/sc/sc3.jpg',info:'手机馆',sale:'享白天免息'},
          {id:4,url:'http://127.0.0.1:3000/sc/sc4.jpg',info:'大家电馆',sale:'满千减百'}],[
            {id:5,url:'http://127.0.0.1:3000/sc/sc5.jpg',info:'进口馆',sale:'满199减100'},
            {id:6,url:'http://127.0.0.1:3000/sc/sc6.jpg',info:'生鲜馆',sale:'尝鲜秒杀'},
            {id:7,url:'http://127.0.0.1:3000/sc/sc7.jpg',info:'小家电馆',sale:'满减狂欢'},
            {id:8,url:'http://127.0.0.1:3000/sc/sc8.jpg',info:'内衣馆',sale:'年终狂欢购'},
            {id:9,url:'http://127.0.0.1:3000/sc/sc9.jpg',info:'医药城',sale:'大牌直降'},
            {id:10,url:'http://127.0.0.1:3000/sc/sc10.jpg',info:'美妆馆',sale:'领免费使用'},
            {id:11,url:'http://127.0.0.1:3000/sc/sc11.jpg',info:'鞋靴箱包',sale:'低至五折'}, 
            {id:12,url:'http://127.0.0.1:3000/sc/sc12.jpg',info:'电脑办公',sale:'新品好价够'}]]
            res.send(obj);

})

module.exports=router;

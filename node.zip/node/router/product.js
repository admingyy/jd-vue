const express=require('express');
const router=express.Router();
const pool=require('../pool.js');

router.get('/product',(req,res)=>{
    var sql='select pid,name,router from app_product'
    pool.query(sql,[],(err,result)=>{
       if(err) throw err;
       res.send(result);
    })
})

router.get('/pswipe',(req,res)=>{
    var sql='select url from app_swipe'
    pool.query(sql,[],(err,result)=>{
        if(err) throw err;
        res.send(result);
     })
})
//手机的分类
router.get('/mobile',(req,res)=>{
  var sql='select url,info from app_mobile'
    pool.query(sql,[],(err,result)=>{
        if(err) throw err;
        res.send(result);
     }) 
})
//电脑的分类
router.get('/computer',(req,res)=>{
    var sql='select id,url,info from app_computer'
    pool.query(sql,[],(err,result)=>{
        if(err) throw err;
        res.send(result);
     }) 
})
router.get('/bao',(req,res)=>{
    var type=req.query.type;
    var index=req.query.pageIndex;
    var count=req.query.pageCount;
    var can=req.query.order;   //可变参数
   var offset=parseInt((index-1)*count)
    var count=parseInt(count);
    var obj={};
    var process=0;
    var sql='select pno from c_type where type=?';
    pool.query(sql,[type],(err,result)=>{
        if(err) throw err;
       var c=result.length;
        var size=Math.ceil(c/count);
        obj.size=size;
        process+=50;
        if(process==100){
            res.send(obj);
        }
     }) 
     if(can==null){
        var sql1='select * from c_type where type=? limit ?,?';
     }else{
      var sql1='select * from c_type where type = ? ORDER BY price ASC limit ?,?';//传参问题  --order by  变不了
     }
   
    pool.query(sql1,[type,offset,count],(err,result)=>{
        if(err) throw err;
        obj.res=result
        process+=50;
        if(process==100){
            res.send(obj);
        }
     }) 
})
//商品详情
router.get('/detail',(req,res)=>{
  var pno=req.query.pno;
  var pname=req.query.pname;
  var obj={};
  var process=0;
var sql='select url from detail where pname=?'
pool.query(sql,[pname],(err,result)=>{
    if(err) throw err;
    process+=50;
    obj.swipe=result;
    if(process==100)
    res.send(obj);
})
var sql1='select * from c_type  where pno=?'
pool.query(sql1,[pno],(err,result)=>{
    if(err) throw err;
    process+=50;
    obj.info=result;
    if(process==100)
    res.send(obj);
})
})

router.get('/chart',(req,res)=>{
    var pno=req.query.pno;
    var pname=req.query.pname;
    console.log(pno)
    var sql='select * from c_type where pno= ?'
     /*pool.query(sql,[pno],(err,result)=>{
        if(err) throw err;
        res.send(result);
     })*/

})
router.get('/car',(req,res)=>{   //购物车加载
    var sql='select pno,count from car where count > 0';
    var a=[];
    var g={};
    pool.query(sql,[],(err,result)=>{
        if(err) throw err;
        g.count=result;
        var sql='select * from c_type where pno in'
        for(li of result){
              a.push(li.pno)
        }
        var str=a.toString();
        var s='('+str+')'
        var sql1=sql+s;
       //  console.log(str);
      pool.query(sql1,a,(err,result)=>{
          g.detail=result;
            res.send(g);
        })

    })
})
router.post('/car_info',(req,res)=>{   //写入数据
  var pno=req.body.pno;
  var count=0;
var sql='select * from car where pno=?'
pool.query(sql,[pno],(err,result)=>{
  if(err) throw err;
  count=result[0].count
  if(result.length<1){
      count=1
      var sql1='insert into car values(?,?)'
    pool.query(sql1,[pno,count],(err,result)=>{
        if(err) throw err;
      })
  }else{
      count++
      var sql2='update car set count=? where pno=?'
      pool.query(sql2,[count,pno],(err,result)=>{
        if(err) throw err;
      })
  }

})

})
router.get('/shu',(req,res)=>{  //显示购物车数量
    var sql='select count(pno) as c from car where count > 0'
    pool.query(sql,[],(err,result)=>{
        res.send(result);
    })
})
module.exports=router;
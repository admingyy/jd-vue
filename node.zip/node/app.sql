-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2018-12-03 05:05:33
-- 服务器版本： 10.1.28-MariaDB
-- PHP Version: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `app`
--

-- --------------------------------------------------------

--
-- 表的结构 `app_computer`
--

CREATE TABLE `app_computer` (
  `id` int(11) NOT NULL,
  `url` varchar(128) DEFAULT NULL,
  `info` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `app_computer`
--

INSERT INTO `app_computer` (`id`, `url`, `info`) VALUES
(1, 'http://127.0.0.1:3000/computer/c1.png', '轻薄本'),
(2, 'http://127.0.0.1:3000/computer/c2.png', '游戏本'),
(3, 'http://127.0.0.1:3000/computer/c3.jpg', '机械键盘'),
(4, 'http://127.0.0.1:3000/computer/c4.jpg', '组装电脑'),
(5, 'http://127.0.0.1:3000/computer/c5.jpg', '移动硬盘'),
(6, 'http://127.0.0.1:3000/computer/c6.jpg', '显卡'),
(7, 'http://127.0.0.1:3000/computer/c7.jpg', '游戏台式机'),
(8, 'http://127.0.0.1:3000/computer/c8.jpg', '家用打印机'),
(9, 'http://127.0.0.1:3000/computer/c9.jpg', '吃鸡装备'),
(10, 'http://127.0.0.1:3000/computer/c10.jpg', '曲屏显示器'),
(11, 'http://127.0.0.1:3000/computer/c11.jpg', '投影机'),
(12, 'http://127.0.0.1:3000/computer/c12.jpg', '日本文具');

-- --------------------------------------------------------

--
-- 表的结构 `app_mobile`
--

CREATE TABLE `app_mobile` (
  `id` int(11) NOT NULL,
  `url` varchar(128) DEFAULT NULL,
  `info` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `app_mobile`
--

INSERT INTO `app_mobile` (`id`, `url`, `info`) VALUES
(1, 'http://127.0.0.1:3000/mobile/s1.png', '小米'),
(2, 'http://127.0.0.1:3000/mobile/s2.jpg', '华为'),
(3, 'http://127.0.0.1:3000/mobile/s3.jpg', '荣耀'),
(4, 'http://127.0.0.1:3000/mobile/s4.jpg', 'iphone'),
(5, 'http://127.0.0.1:3000/mobile/s5.png', 'vivo'),
(6, 'http://127.0.0.1:3000/mobile/s6.png', 'oppo'),
(7, 'http://127.0.0.1:3000/mobile/s7.jpg', '魅族'),
(8, 'http://127.0.0.1:3000/mobile/s8.png', '三星'),
(9, 'http://127.0.0.1:3000/mobile/s9.jpg', '一加'),
(10, 'http://127.0.0.1:3000/mobile/s10.jpg', '360手机'),
(11, 'http://127.0.0.1:3000/mobile/s11.jpg', '锤子手机'),
(12, 'http://127.0.0.1:3000/mobile/s12.jpg', '努比亚');

-- --------------------------------------------------------

--
-- 表的结构 `app_product`
--

CREATE TABLE `app_product` (
  `pid` int(11) NOT NULL,
  `name` varchar(48) DEFAULT NULL,
  `router` varchar(26) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `app_product`
--

INSERT INTO `app_product` (`pid`, `name`, `router`) VALUES
(1, '手机数码', 'mobile'),
(2, '电脑办公', 'computer'),
(3, '家用电器', NULL),
(4, '计生情趣', NULL),
(5, '美妆护肤', NULL),
(6, '个护清洁', NULL),
(7, '汽车用品', NULL),
(8, '京东超市', NULL),
(9, '男装', NULL),
(10, '男鞋', NULL),
(11, '女装', NULL),
(12, '女鞋', NULL),
(13, '母婴童装', NULL),
(14, '图书音像', NULL),
(15, '运动户外', NULL),
(16, '内衣配饰', NULL),
(17, '食品生鲜', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `app_swipe`
--

CREATE TABLE `app_swipe` (
  `pid` int(11) NOT NULL,
  `sn` varchar(8) DEFAULT NULL,
  `url` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `app_swipe`
--

INSERT INTO `app_swipe` (`pid`, `sn`, `url`) VALUES
(1, 'p1', 'http://127.0.0.1:3000/p_swip/p1.jpg'),
(2, 'p1', 'http://127.0.0.1:3000/p_swip/p2.jpg'),
(3, 'p1', 'http://127.0.0.1:3000/p_swip/p3.jpg'),
(4, 'p1', 'http://127.0.0.1:3000/p_swip/p4.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `app_user`
--

CREATE TABLE `app_user` (
  `id` int(11) NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  `pwd` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `app_user`
--

INSERT INTO `app_user` (`id`, `name`, `pwd`) VALUES
(1, 'gyy', 'admin'),
(2, 'yj', '123'),
(3, 'yjh', '123'),
(8, 'hsm', '123456'),
(9, 'yong', '123'),
(10, '', ''),
(11, 'ge', '123456');

-- --------------------------------------------------------

--
-- 表的结构 `car`
--

CREATE TABLE `car` (
  `pno` int(11) NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `car`
--

INSERT INTO `car` (`pno`, `count`) VALUES
(1, 8),
(2, 2),
(3, 2),
(4, 1),
(5, 1),
(6, 0),
(7, 0),
(8, 0),
(9, 0),
(10, 0),
(11, 1),
(12, 0),
(13, 0);

-- --------------------------------------------------------

--
-- 表的结构 `c_type`
--

CREATE TABLE `c_type` (
  `pno` int(11) NOT NULL,
  `type` int(11) DEFAULT NULL,
  `url` varchar(64) DEFAULT NULL,
  `title` varchar(128) DEFAULT NULL,
  `price` decimal(7,2) DEFAULT NULL,
  `detail` varchar(64) DEFAULT NULL,
  `isjd` tinyint(1) DEFAULT NULL,
  `comment` int(11) DEFAULT NULL,
  `pnumber` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `c_type`
--

INSERT INTO `c_type` (`pno`, `type`, `url`, `title`, `price`, `detail`, `isjd`, `comment`, `pnumber`) VALUES
(1, 1, 'http://127.0.0.1:3000/bao/b1.jpg', '华为(HUAWEI) MateBook D(2018版) 15.6英寸轻薄微边框笔记本(i5-8250U 8G 256G MX150 2G独显FHD office)黑', '5188.00', '锐龙  5256G固态 15.1mm—20.0mm', 0, 7, 1),
(2, 1, 'http://127.0.0.1:3000/bao/b2.jpg', '小米 14英寸轻薄窄边框笔记本电脑（AMD锐龙5 8G 256G FHD IPS 正版Office）冰河银', '3898.00', '锐龙  5256G固态 15.1mm—20.0mm', 1, 8, 2),
(3, 1, 'http://127.0.0.1:3000/bao/b3.jpg', '戴尔灵越14 燃 14英寸轻薄窄边框笔记本电脑(i5-8265U 8G 256GSSD MX150 2G独显 背光键盘）冰河银 ', '5599.00', 'Intel i5低功耗版 256G固态', 1, 12, 3),
(4, 1, 'http://127.0.0.1:3000/bao/b4.jpg', '机械革命(MECHREVO)S1 72%IPS1.18kg14英寸独显窄边框轻薄笔记本电脑i7-8550U 8G 256G MX150 灰 OFFICE 背光', '5188.00', 'Intel i5低功耗版 256G固态', 0, 1, 4),
(5, 1, 'http://127.0.0.1:3000/bao/b5.jpg', '联想ThinkPad 翼480（0VCD）英特尔8代酷睿14英寸轻薄窄边框笔记本电脑（i5-8250U 8G 128GSSD+500G 2G独显)', '5698.00', 'Intel i7 128G+500G', 1, 9, 5),
(6, 1, 'http://127.0.0.1:3000/bao/b6.jpg', 'iPhone macbook 14英寸轻薄窄边框笔记本电脑（i5-8250U 8G 256G MX150 2G独显 FHD IPS 正版Office）冰河银', '4898.00', ' ', 0, 6, 6),
(7, 1, 'http://127.0.0.1:3000/bao/b7.jpg', '华为(HUAWEI) MateBook D(2018版) 15.6英寸轻薄微边框笔记本(i5-8250U 8G 256G MX150 2G独显FHD office)黑', '5188.00', '锐龙  5256G固态 15.1mm—20.0mm', 0, 4, 1),
(8, 1, 'http://127.0.0.1:3000/bao/b8.jpg', '荣耀 14英寸轻薄窄边框笔记本电脑（AMD锐龙5 8G 256G FHD IPS 正版Office）冰河银', '3898.00', '锐龙  5256G固态 15.1mm—20.0mm', 1, 10, 1),
(9, 1, 'http://127.0.0.1:3000/bao/b9.jpg', '戴尔灵越14 燃 14英寸轻薄窄边框笔记本电脑(i5-8265U 8G 256GSSD MX150 2G独显 背光键盘）冰河银 ', '5599.00', 'Intel i5低功耗版 256G固态', 1, 3, 3),
(10, 1, 'http://127.0.0.1:3000/bao/b10.jpg', '机械革命(MECHREVO)S1 72%IPS1.18kg14英寸独显窄边框轻薄笔记本电脑i7-8550U 8G 256G MX150 灰 OFFICE 背光', '5188.00', 'Intel i5低功耗版 256G固态', 0, 13, 4),
(11, 1, 'http://127.0.0.1:3000/bao/b11.jpg', '联想ThinkPad 翼480（0VCD）英特尔8代酷睿14英寸轻薄窄边框笔记本电脑（i5-8250U 8G 128GSSD+500G 2G独显)', '5698.00', 'Intel i7 128G+500G', 1, 1, 5),
(12, 1, 'http://127.0.0.1:3000/bao/b12.jpg', '荣耀MagicBook 14英寸轻薄窄边框笔记本电脑（i5-8250U 8G 256G MX150 2G独显 FHD IPS 正版Office）冰河银', '4898.00', ' ', 0, 7, 1),
(13, 1, 'http://127.0.0.1:3000/bao/b13.jpg', '戴尔 14英寸轻薄窄边框笔记本电脑（AMD锐龙5 8G 256G FHD IPS 正版Office）冰河银', '3898.00', '锐龙  5256G固态 15.1mm—20.0mm', 1, 8, 3),
(14, 1, 'http://127.0.0.1:3000/bao/b14.jpg', '戴尔灵越14 燃 14英寸轻薄窄边框笔记本电脑(i5-8265U 8G 256GSSD MX150 2G独显 背光键盘）冰河银 ', '5599.00', 'Intel i5低功耗版 256G固态', 1, 16, 3),
(15, 1, 'http://127.0.0.1:3000/bao/b15.jpg', '机械革命(MECHREVO)S1 72%IPS1.18kg14英寸独显窄边框轻薄笔记本电脑i7-8550U 8G 256G MX150 灰 OFFICE 背光', '5188.00', 'Intel i5低功耗版 256G固态', 0, 3, 4);

-- --------------------------------------------------------

--
-- 表的结构 `detail`
--

CREATE TABLE `detail` (
  `id` int(11) NOT NULL,
  `pname` int(11) DEFAULT NULL,
  `url` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `detail`
--

INSERT INTO `detail` (`id`, `pname`, `url`) VALUES
(1, 1, 'http://127.0.0.1:3000/huawei/hw1.jpg'),
(2, 1, 'http://127.0.0.1:3000/huawei/hw2.jpg'),
(3, 1, 'http://127.0.0.1:3000/huawei/hw3.jpg'),
(4, 1, 'http://127.0.0.1:3000/huawei/hw4.jpg'),
(5, 1, 'http://127.0.0.1:3000/huawei/hw5.jpg'),
(6, 1, 'http://127.0.0.1:3000/huawei/hw6.jpg'),
(7, 2, 'http://127.0.0.1:3000/xiaomi/xm1.jpg'),
(8, 2, 'http://127.0.0.1:3000/xiaomi/xm2.jpg'),
(9, 2, 'http://127.0.0.1:3000/xiaomi/xm3.jpg'),
(10, 2, 'http://127.0.0.1:3000/xiaomi/xm4.jpg'),
(11, 2, 'http://127.0.0.1:3000/xiaomi/xm5.jpg'),
(12, 2, 'http://127.0.0.1:3000/xiaomi/xm6.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_computer`
--
ALTER TABLE `app_computer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_mobile`
--
ALTER TABLE `app_mobile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_product`
--
ALTER TABLE `app_product`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `app_swipe`
--
ALTER TABLE `app_swipe`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `app_user`
--
ALTER TABLE `app_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`pno`);

--
-- Indexes for table `c_type`
--
ALTER TABLE `c_type`
  ADD PRIMARY KEY (`pno`);

--
-- Indexes for table `detail`
--
ALTER TABLE `detail`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `app_computer`
--
ALTER TABLE `app_computer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- 使用表AUTO_INCREMENT `app_mobile`
--
ALTER TABLE `app_mobile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- 使用表AUTO_INCREMENT `app_product`
--
ALTER TABLE `app_product`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- 使用表AUTO_INCREMENT `app_swipe`
--
ALTER TABLE `app_swipe`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- 使用表AUTO_INCREMENT `app_user`
--
ALTER TABLE `app_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- 使用表AUTO_INCREMENT `car`
--
ALTER TABLE `car`
  MODIFY `pno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- 使用表AUTO_INCREMENT `c_type`
--
ALTER TABLE `c_type`
  MODIFY `pno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- 使用表AUTO_INCREMENT `detail`
--
ALTER TABLE `detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

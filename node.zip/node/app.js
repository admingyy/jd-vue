const express=require('express');
const pool=require('./pool');
const cors=require('cors');
const app=express();
const home=require('./router/home')
const user=require('./router/user')
const product=require('./router/product')
const bodyParser = require('body-parser');
app.listen(3000,()=>{
    console.log('ok')
})
//轮播图片
app.use(cors({
    origin:'*',
    credentials:true
}))
app.use(express.static(__dirname+'/public'));
app.use(bodyParser.urlencoded({extended:false}))
app.use('/home',home)
app.use('/user',user)
app.use('/product',product)
<template>
  <div class="my">
      <mt-header>
        <router-link to="/home" slot="left">
          <mt-button icon="back">返回</mt-button>
        </router-link>
        <mt-button icon="more" slot="right" @click="moreVisiable = true"></mt-button>
      </mt-header>
      <p>欢迎 ！{{name}}</p>
      <img src="../assets/user.jpg" alt="">
      <mt-button class='last' size='large' @click='out()'>退出当前账号</mt-button>
        
  </div>
</template>
<script>
export default ({  
    data(){
        return{
             name:''
        }
    },
    methods:{
        hel(){
           var val= sessionStorage.getItem('name');
            this.name=val;
        },
        out(){
            sessionStorage.clear();
            this.$router.push('/home')
        }
    },
    created() {
        this.hel()
    },
  })
</script>
<style>
  .my{
    width:100%;
  }
  .my .last{
      margin-top:20rem;
  }
 
</style>
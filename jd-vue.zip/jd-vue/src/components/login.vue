<template>
    <div class='app-login'>
      <mt-header title="京东登录">
        <router-link to="/home" slot="left">
         <mt-button icon="back"></mt-button>
         </router-link>
      </mt-header>
          <div class="name">
             <input type="text" placeholder="用户名/邮箱、已验证手机" name='uname' required v-model="name">
             <span @click='clear()'>X</span>
          </div>
          <div class='pwd'>
              <input type="password" placeholder="请输入密码" name='upwd' required v-model='pwd'><span>|</span>忘记密码
          </div>
          <mt-button class='login' type="danger" size="large" @click='submit()'>登录</mt-button>
          <mt-button class='btn' size="large">一键登录</mt-button>
          <div class='type'>
              <span>短信验证码登录</span>
              <span @click='register()'>手机快速注册</span>
          </div>
          <div class='other'>
                <span>其他登录方式</span>
                <div class="content">
                    <div class='qq'>
                      <div></div>
                       <span>QQ</span>
                    </div>
                    <div class='wx'>
                        <div></div>
                       <span>微信</span>
                    </div>
                </div>
                <span>登录即代表您已同意 <router-link to=''>京东隐私政策</router-link></span>
          </div>
    </div>
</template>
<script>
import { Toast } from 'mint-ui';
    export default({
      data(){
          return{
           name:'',
           pwd:'',
          }
      },
      created(){
          
      },
      mounted() {
          this.test();
      },
      methods:{
       clear(){
          this.name='';
       },
       register(){
           this.$router.push('/register');
       },
       test(){ //全程监测
           var div=document.getElementsByClassName('name')[0];
           var input=div.children[0];
           var span=div.children[1];
           var div1=document.getElementsByClassName('pwd')[0];
           var pwd=div1.children[0];
            var btn=document.getElementsByClassName('login')[0];
           span.style.visibility='hidden';
            btn.disabled=true;
              div.onmouseenter=function(){
                 span.style.visibility=''
              }
            div.onmouseleave=function(){
            span.style.visibility='hidden';
            if(pwd.value==''||input.value==''){
               btn.disabled=true;
           }else{
               btn.disabled=false;
           }
          }   
          pwd.oninput=function(){
               if(pwd.value==''||input.value==''){
                 btn.disabled=true;
              }else{
               btn.disabled=false;
           }
          }
       },
       submit(){
           this.$axios.post('http://127.0.0.1:3000/user/log',this.qs.stringify({
              uname:this.name,
              upwd:this.pwd
          })).then(res=>{
            if(res.data.length>0){
                Toast('登陆成功');
                this.$router.push('/home');
                sessionStorage.setItem('name',this.name)
            }else{
                Toast('用户名或密码错误'); 
            }
          })
       }
      }


    })
</script>
<style>
    .app-login .mint-header{
        background: #fff;
        color:black;
        font-size: 1.2rem;
    }
    .app-login .name{
        width:90%;
        margin:0 auto;
        padding-top:3rem;
        border-bottom: 1px solid #ccc;
    }
    .app-login .name input{
        border:0;
        margin:0;
        padding:0;
        width: 90%;
    }
    .app-login .pwd{
         width:90%;
        margin:0 auto;
        padding-top:2rem;
        margin-bottom: 2rem;
        border-bottom: 1px solid #ccc;
    }
    .app-login .pwd input{
        border:0;
        margin:0;
        padding:0;
        width: 70%;
    }
   .app-login .mint-button{
       width:80%;
       margin:0 auto;
       height:4rem;
       margin-bottom: 0.7rem;
       border-radius: 2rem;
   }
   .app-login .btn{
       color:red;
       border:1px solid red;
   }
   .app-login .type{
       display: flex;
       justify-content:space-between;
       padding:1rem 1.5rem;
   }
   .app-login .other{
      padding-bottom: 5.5rem;
   }
   .app-login .other .content .qq div{
       width: 5rem;
       height:5rem;
       background: url('../assets/t1.jpg');
       background-position: 9% 10%;
   }
     .app-login .other .content .wx div{
         width: 5rem;
       height:5rem;
       background: url('../assets/t1.jpg');
       background-position: 9% 45%;
     }
     .app-login .other .content{
         margin-top:2rem;
         margin-bottom: 2rem;
     }
      .app-login .other .content > div{
          text-align:left;
          width:25%;
      }
       .app-login .other .content > div>span{
           padding-left:1rem;
       }
      .app-login .other .content{
          display: flex;
          justify-content: center;
      }
</style>

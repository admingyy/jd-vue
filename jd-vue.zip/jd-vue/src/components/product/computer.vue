<template>
    <div class='app-computer'>
         <h4 style='text-align:left;'>热卖分类</h4>
      <ul>
         <li v-for="li of name" :key='li.item' @click='info(li.id)'>
           <img :src="li.url" alt="">
           <p>{{li.info}}</p>
         </li> 
      </ul>
       <h4 style='text-align:left;'>电脑整机</h4>
      <ul>
         <li v-for="li of name" :key='li.item'>
           <img :src="li.url" alt="">
           <p>{{li.info}}</p>
         </li> 
      </ul>
    </div>
</template>
<script>
    export default({
       data(){
           return{
               name:[],
           }
       },
       created(){
         this. getname()
       },
       methods:{
          getname(){
              this.$axios.get('http://127.0.0.1:3000/product/computer').then(res=>{
                  this.name=res.data
              })
          },
          info(i){
            this.$router.push('/product_info?type='+i);
          }
       }
    
    })
</script>
<style>
    .app-computer ul{
        width:100%;
        display: flex;
        list-style: none;
        margin:0;
        padding:0;
        flex-flow:row wrap;
    }
     .app-computer ul li{
        width:33%;
     }
      .app-computer ul li img{
          width:80%;
          height:60%;
      }

</style>
<template>
    <div class='app-family'>
        <mt-header title='商品分类' >
            <router-link to="/home" slot="left">
              <mt-button icon="back"></mt-button>
            </router-link>
              <mt-button icon="more" slot="right"></mt-button>
        </mt-header>
        <div class='content'>
          <div class='left'>
              <ul>
                  <li v-for='li of product' :key='li.item' @click="pt(li.router)">{{li.name}}</li>
              </ul> 
          </div>
          <div class='right'>
            <mt-swipe :auto="3000" class='swipe'>
                <mt-swipe-item v-for='li of swipe' :key='li.item'><router-link to='/hello'><img :src='li.url'></router-link></mt-swipe-item>
             </mt-swipe>
             <!--引入子组件-->
              <router-view/>
          </div>  
        </div>
<!--尾部-->
        <nav class="mui-bar mui-bar-tab">
			<router-link class="mui-tab-item " to="/home">
				<span class="mui-icon mui-icon-home"></span>
				<span class="mui-tab-label">首页</span>
			</router-link>
			<router-link class="mui-tab-item" to="/family">
				<span class="mui-icon mui-icon-search">
         </span>
				<span class="mui-tab-label">分类</span>
			</router-link>
			<a class="mui-tab-item" href="#tabbar-with-contact">
                   <img src="../../assets/gou.png" alt="" class='gou'>
			</a>
			<a class="mui-tab-item" @click.prevent='shop_car()'>
				<span class="mui-icon mui-icon-extra mui-icon-extra-cart">
           <span class="mui-badge">{{a}}</span>
        </span>
				<span class="mui-tab-label">购物车</span>
			</a>
      <a  class="mui-tab-item" @click.prevent='go()' :class="islogin?'mui-active':''">
				<span class="mui-icon mui-icon-contact"></span>
				<span class="mui-tab-label" >{{islogin?'已登录':'未登录'}}</span>
			</a>
		</nav>
    </div>
</template>
<script>
import { Toast } from 'mint-ui';
    export default({
       data(){
           return{
             product:[],
             swipe:[],
             islogin:0,
             a:0
           }
       },
       created(){
          this.getfamily()
           this.getswipe()
           this.shu()
       },
       methods:{
           getfamily(){
               this.$axios.get('http://127.0.0.1:3000/product/product').then(res=>{
                  this.product=res.data;
               })
           },
           getswipe(){
               this.$axios.get('http://127.0.0.1:3000/product/pswipe').then(res=>{
                  this.swipe=res.data;
               })
           },
           pt(i){
               this.$router.push(`/family/${i}`)
           },
           login(){
               var value=sessionStorage.getItem('name');
               if(value==null){
                   this.islogin=0;
               }else{
                   this.islogin=1;
               }
           },
           shop_car(){
          var val=sessionStorage.getItem('name');
          if(val==null){
            Toast('请先登录')
            return;
          }else{
            this.$router.push('/e_chart');
          }
        },
     shu(){
           this.$axios.get('http://127.0.0.1:3000/product/shu').then(res=>{
              this.a=res.data[0].c
           })
        },
        go(){
            var val=sessionStorage.getItem('name')
          if(val==null){
              this.$router.push('/login')
          }else{
              this.$router.push('/checkout')
          }
        }
       },
       mounted(){
           this.login()
       }

    })
</script>
<style>
      .app-family{
       background: #EFEFF4;
    }
     .app-family .mint-header{
       background: #EFEFF4;
        color:black;
        font-size: 1.2rem;
    }
    .app-family .content{
        border-top:1px solid #ccc;
        position:absolute;
        width:100%;
        height:85%;
        display:flex;
    }
  .app-family .content .left{
      width:25%;
      overflow: auto;
      height:100%;
  }
  .app-family .content .left ul{
      list-style: none;
      margin:0;
      padding:0;
      text-align: center;
  }
   .app-family .content .left ul li{
       padding:1rem 0;
   }
  .app-family .content .right{
      width:75%;
      overflow: auto;
      height:100%;
  }
  .app-family .gou{
      width: 100%;
      height:100%;
    margin-top: 0.2rem;
  }
  .app-family .content .right .swipe{
     width:100%;
     height:10rem;
  }
  .app-family .content .right .swipe img{
      width:100%;
      height:100%;
  }
</style>
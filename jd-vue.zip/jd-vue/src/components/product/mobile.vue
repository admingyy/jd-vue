<template>
    <div class='app-mobile'>
        <h4 style='text-align:left;'>热门品牌</h4>
      <ul>
         <li v-for="li of name" :key='li.item'>
           <img :src="li.url" alt="">
           <p>{{li.info}}</p>
         </li> 
      </ul>
    </div>
</template>
<script>
    export default({
       data(){
           return{
               name:[],
           }
       },
       created(){
         this. getname()
       },
       methods:{
          getname(){
              this.$axios.get('http://127.0.0.1:3000/product/mobile').then(res=>{
                  this.name=res.data
              })
          }

       }
    
    })
</script>
<style>
    .app-mobile ul{
        width:100%;
        display: flex;
        list-style: none;
        margin:0;
        padding:0;
        flex-flow:row wrap;
    }
     .app-mobile ul li{
        width:33%;
     }
      .app-mobile ul li img{
          width:80%;
          height:60%;
      }

</style>
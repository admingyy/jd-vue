<template>
    <div class='app-cart'>
        <ul class='header' >
          <li @click="back()">返回</li>
          <li class='deft'>商品</li>
          <li>评价</li>
          <li>详情</li>
          <li>推荐</li>
        </ul>
       <!--轮播图    2：-->
      <mt-swipe  :auto="4000">
        <mt-swipe-item v-for='li of list.swipe' :key='li.item'>
           <img :src='li.url'/>
        </mt-swipe-item>
      </mt-swipe>
      <!--price-->
      <div class="price">
        <span class="sp1">￥{{(info.price)}}.00</span>
        <span class="sp3">京东秒杀</span>
      </div> 
      <!--desc-->
      <div class="desc">
       <strong>{{info.isjd==1?"":'自营'}}</strong><span>{{info.title}}</span>
       <p>[办公利器]{{info.detail}}</p>
      </div>

      <div class="add-cart">
        <div class="add-cart_join" @click='e_car()'>加入购物车</div> 
        <div class="add-cart_pay">立即秒杀</div>
      </div>
   </div>
</template>
<script>
import { Toast } from 'mint-ui';
  export default {
    data(){
      return {
         list:[],
         info:{},
      }
    },
    methods:{ 
      getImage(){
        //发送ajax请求并且获取图片列表并且显示
        var pno=this.$route.query.pno;
        var pname=this.$route.query.pname;
        this.$axios.get('http://127.0.0.1:3000/product/detail',{
            params:{
                pno:pno,
                pname:pname,
            }
        }).then(res=>{
             this.list=res.data
             this.info=this.list.info[0]
        })
      },
      back(){
      this.$router.push('/family')
       },
       e_car(){
         // this.$store.commit('increment',1);
          Toast('添加成功')
        var pno=this.$route.query.pno;
        var pname=this.$route.query.pname;
       var n=sessionStorage.getItem('pno');
        var m=sessionStorage.getItem('pname');
        this.$axios.post('http://127.0.0.1:3000/product/car_info',this.qs.stringify({
            pno:pno
        })).then(res=>{
            
        })
       }
    },
    created(){
      this.getImage();
    },
    
  }
</script>
<style>
.deft{
    color:#e4393c;
}
.app-cart .header{
    background: rgb(99, 161, 182);
}
  .app-cart .mint-swipe{
    width:100%;
    height:22rem;
  }
  .app-cart .mint-swipe img{
    width:100%;
    height:100%;
  }
  
  .app-cart .header{
       padding:0;
       margin:0;
       list-style-type: none;
       display: flex;
       justify-content: flex-start;
  }
  .app-cart .header li{
    width:20%;
    padding:1rem;
  }
  .price{
    width:100%;
    height:80px;
    background:linear-gradient(to right,#FF7D4D 0%,#FF4B3B 100%);
    display: flex;
    align-items: center;
    padding-left:30px;

  }
  .price span{
    display:block;
    color:#fff;
  }
  .price .sp1{
    font-size: 2rem;
  }

  .price .sp3{
    font-size: 1rem;margin-left:2rem;
  }
  .desc{
      text-align: left;
  }
  .desc p{
      color:#e4393c;
  }
  .desc strong{
      color:#e4393c;
      font-size: 1.4rem;
  }
  .add-cart{
    width:100%;height:50px;
    position:absolute;bottom:0;

  }

  .add-cart .add-cart_join,
  .add-cart .add-cart_pay
  {
    width:100px;height:50px;float:left;
    display: flex;
    justify-content: center;
    align-items: center;
    color:#fff;
    font-size: 16px;
  }
  .add-cart .add-cart_join{background:#ff9600;margin-left:46%;}
  .add-cart .add-cart_pay{background:#e4393c;}
</style>
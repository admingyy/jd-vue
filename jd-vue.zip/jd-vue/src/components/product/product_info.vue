<template>
    <div class='app-product_info'>
       <mt-header title="商品列表">
        <router-link to="/family" slot="left">
         <mt-button icon="back"></mt-button>
         </router-link>
      </mt-header>
      <div class='header'>
       <ul>
           <li :class='h==1?"default":""' @click='getpno(null)'>综合</li>
           <li @click="getpno('price')"  :class='h==2?"default":""' >价格</li>
           <li>销量</li>
           <li>筛选</li>
       </ul>
      </div>
      <div>
      </div>
<!--内容-->
    <ul class="content">
       <li v-for='li of content.res' :key='li.item' @click='detail(li.pnumber,li.pno)'>
         <img :src="li.url" alt="" >
          <div class='right'>
            <p>{{li.title}}</p>
            <p>{{li.detail}}</p>
            <p>￥{{li.price.toFixed(2)}}</p>
            <p><span>{{li.isjd?'自营':''}}</span>&nbsp;<a>{{li.comment}}万条评价,好评率98%</a></p>
          </div>
       </li>
    </ul>
    <div class='footer'>
      <ul>
          <li :class='f==1?"disabled":""' >上一页</li>
          <li v-for='i of fy' :key='i' :class='pageIndex==i?"default":""' @click='next(i)'>{{i}}<li>
          <li :class='f==3?"disabled":""'>下一页</li> 
      </ul>
    </div>
    </div>
</template>
<script>
    export default({
       data(){
           return{
               h:1,
               content:{},
               type:'',
               pageIndex:1,
               pageCount:5,
               fy:[],
               f:1,
           }
       },
       created(){
         this.getpno();
       },
       methods:{
           getpno(i){
               if(i==null)
               this.h=1;
               else
               this.h=2
               this.type=this.$route.query.type
                this.$axios.get('http://127.0.0.1:3000/product/bao',{
                    params:{
                        order:i,
                        type:this.type,
                        pageIndex:this.pageIndex,
                        pageCount:this.pageCount
                    }
                }).then(res=>{
                   this.content=res.data;
                   var size=res.data.size;
                   var a=[];
                   for(var i=0;i<size;i++){
                       a[i]=i+1;
                   }
                   this.fy=a;
                })
          },
          next(i){  
              this.pageIndex=i;
               this.f=i
              this.type=this.$route.query.type
                this.$axios.get('http://127.0.0.1:3000/product/bao',{
                    params:{
                        order:i,
                        type:this.type,
                        pageIndex:this.pageIndex,
                        pageCount:this.pageCount
                    }
                }).then(res=>{
                      this.content=res.data;
                    var size=res.data.size;
                    var a=[];
                    for(var i=0;i<size;i++){
                       a[i]=i+1;
                   }
                    this.fy=a;
                     })
          },
          detail(i,a){
              this.$router.push('/detail?pname='+i+'&pno='+a)
          }

       }//methods

    })
</script>
<style>
ul{
    margin:0; padding:0;
    list-style:none;
}
.default{
    color:red;
    background:#f5f5f5;
}
.disabled{
    background:gray !important;
    border-color: gray;
}
   .app-product_info .header ul{
       padding:1rem 0;
      display: flex;
      justify-content: space-around;
   }
   .app-product_info .content{
       box-sizing: border-box;
   }
   .app-product_info .content li{
       display: flex;
       flex-flow: row nowrap;
   }
    .app-product_info .content li img{
        width:40%;
        height:50%
    }
    .app-product_info .content li p{
        margin:0;
        padding:0;
        text-align: left;
        padding-top:0.2rem;
    }
    .app-product_info .content li p:first-child{
        color:#000;
        font-size: 0.9rem;
    }
    .app-product_info .content li p:nth-child(3){
        color:red;
    }
    .app-product_info .content li p:nth-child(4) span{
      color:red;
    }
    .app-product_info .footer{
        position:fixed;
        bottom:0;
        width: 100%;
        padding:0.4rem;
        background:#26A2FF;
        border-radius: 20%;
        display: flex;
        justify-content:center;
    }
    .app-product_info .footer ul{
        display: flex;
    }
    .app-product_info .footer ul li{
        border:1px solid #000;
        color:#000;
        padding:0.5rem;
    }
    .app-product_info .footer ul li+li{
        border-left:0;
    }
</style>
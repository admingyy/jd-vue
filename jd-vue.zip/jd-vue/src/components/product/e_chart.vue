<template>
    <div class="app-car">
      <div class='top1'>
          <span @click='fh()'>返回</span>
          <span>我的购物车</span> 
      </div>
      <ul>
          <li v-for='li of detail' :key='li.id'>
             <img :src="li.url" alt="">
             <div class='rg1'>
                 <p class='pr1'>￥{{li.price.toFixed(2)}}</p>
                 <p class='btn'><span>-</span><span class='count'>1</span><span>+</span></p>
             </div>
          </li>
      </ul>
    </div>
</template>
<script>
import { Toast } from 'mint-ui';
    export default({
      data(){
          return{
              count:[],
              detail:[],
              val:1
          }
      },
      created() {
          this.getmore()
      },
      methods:{
       getmore(){
          this.$axios.get('http://127.0.0.1:3000/product/car').then(res=>{
              this.count=res.data.count;
              this.detail=res.data.detail;
             // console.log(this.count,this.detail)
             if(res.data.length<1){
                 Toast('现在还没买东西 赶快购物吧')
             }
          })
       },
       fh(){
           this.$router.push('/home');
       },
       jian(e){

       },
       jia(e){
         
       }
      },
      mounted() {
          
      },
    })
</script>
<style>
    .app-car .top1{
        display: flex;
        padding: 1rem;
        background:lightblue;
    }
    .app-car .top1 span:nth-child(2){
        margin-left:30%;
    }
  .app-car ul{
      margin:0;
      padding:0;
      list-style: none;
  }
  .app-car ul li{
      display: flex;
      flex-flow: row nowrap;
  }
  .app-car ul li img{
      width:30%;
      height:10%;
  }
  .app-car ul li input{
      width:15%;
     margin:0;
     height:2.5rem;
  }
  .app-car ul li .rg1{
      width:65%;
      display:flex;
      flex-flow: row nowrap;
      justify-content:space-between;
      align-items: center;
  }
  .app-car ul li .rg1 .pr1{
      color:red;
      font-size:1.5rem; 
  }
  .app-car ul li span{
      border:1px solid #ccc;
      display: inline-block;
      width:2.5rem;
      line-height:2rem;
  }

</style>
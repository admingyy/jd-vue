<template>
 <div class='app-home'>
    <div class='header'>
     <span class='first' @click="family()"></span>
      <input type='text' v-model='search' placeholder='请输入搜索内容'>
      <span class='second' @click='login()'>{{islog?'hello! '+`${logname}`:'登录'}}</span>
    </div>
    <mt-swipe :auto="3000" class='swipe'>
      <mt-swipe-item v-for='li of res' :key='li.item'><router-link to='/hello'><img :src='li'></router-link></mt-swipe-item>
    </mt-swipe>
    <img :src='gif[0]'>
     <div class='nav'>
       <router-link v-for='li of nav' :key='li.item' to='/hello'>  
         <img :src="li.url"> <span>{{li.name}}</span>
      </router-link>
     </div>
     <div class='news'>
       <span>京东快报</span>
       <ul>
         <li v-for='li of change' :key='li.item'>{{li}}</li>
       </ul>
       <span @click='link()'>更多</span>
     </div>
     <div class='content'>
         <img  :src="li" v-for='li of content' :key='li.item'>
     </div>
      <div class='sou'>
         <div class='first'>
          <strong>京东秒杀</strong>
          <span>{{date.h}}点场</span>
          <input type="text" v-model="date.last">
          <span class='more'>更多秒杀</span>
          </div>
          <div class='two'>
          <ul >
            <li v-for='li of tu' :key='li.item'>
               <img :src="li.url" alt="">
               <p class='new'>{{li.newprice}}</p>
               <p class='old'>{{li.oldprice}}</p>
            </li>
          </ul>
          </div>
      </div>
        <div class=nav>
           <img src="../assets/big.jpg" alt="">
        </div>
        <div class='store'>
          <ul>
            <li v-for='li of store[0]' :key='li.item'>
              <div>
              <strong>{{li.info}}</strong>
              <p>{{li.sale}}</p>
              </div>
              <img :src="li.url" alt="">
              </li>
          </ul>
        </div>
        <div class='store_two'>
        <ul>
          <li v-for='li of store[1]' :key='li.item' >
            <strong>{{li.info}}</strong>
            <p>{{li.sale}}</p>
            <img :src="li.url" alt="">
          </li>
        </ul>
        </div>
        <hr style='width:80%;'>
        <div class='foot'>
           <ul class='first'>
            <li>登录</li>
            <li>注册</li>
            <li>客户端服务</li>
            <li>返回顶部</li>
           </ul>
        </div>
        <ul class='two'>
          <li><img src="../assets/f1.png" alt=""></li>
          <li><img src="../assets/f2.png" alt=""></li>
          <li><img src="../assets/f3.png" alt=""></li>
        </ul>
        <p class='last'>Copyright © 2004-2018 京东JD.com 版权所有</p>
        <br>
        <br>
        <br>
        <img class='top' src="../assets/top.jpg" alt="" @click='top()'>
     <nav class="mui-bar mui-bar-tab">
			<router-link class="mui-tab-item mui-active" to="/home">
				<span class="mui-icon mui-icon-home"></span>
				<span class="mui-tab-label">首页</span>
			</router-link>
			<router-link class="mui-tab-item" to="/family">
				<span class="mui-icon mui-icon-search">
         </span>
				<span class="mui-tab-label">分类</span>
			</router-link>
			<a class="mui-tab-item" href="#tabbar-with-contact">
			   <img src="../assets/tab.png" alt="">
			</a>
			<a class="mui-tab-item" @click.prevent='shop_car()' >
				<span class="mui-icon mui-icon-extra mui-icon-extra-cart">
           <span class="mui-badge">{{a}}</span>
        </span>
				<span class="mui-tab-label">购物车</span>
			</a>
      <router-link  class="mui-tab-item" :class='islog?"mui-active":""' to='/login'>
				<span class="mui-icon mui-icon-contact"></span>
				<span class="mui-tab-label" >{{islog?'已登录':'未登录'}}</span>
			</router-link>
		</nav>
 </div>
</template>
<script>
import { Toast } from 'mint-ui';
   export default{
     data(){
        return{
          res:[],
          search:'',
          gif:[],
          nav:[],
          change:[],
          content:[],
          date:{h:'',last:''},
          tu:[],
          store:[],
          islog:0,
          logname:'',
          a:0
        }
     },
     created(){
       this.getswipe(),
       this.getgif(),
       this.getnav(),
       this.getchange(),
       this.getcontent(),
       this.getsou(),
       this.getstore(),
       this.shu()
       
     },
      methods:{
         shu(){
           this.$axios.get('http://127.0.0.1:3000/product/shu').then(res=>{
              this.a=res.data[0].c
           })
        },
        family(){
          this.$router.push('/family');
        },
        getswipe(){
         this.$axios.get('http://127.0.0.1:3000/home/swipe').then(res=>{
            this.res=res.data;
           })
        },
        getgif(){
           this.$axios.get('http://127.0.0.1:3000/home/gif').then(res=>{
            this.gif=res.data;
           })
        },
        getnav(){
           this.$axios.get('http://127.0.0.1:3000/home/nav').then(res=>{
            this.nav=res.data;
           })
        },
        getchange(){
            this.$axios.get('http://127.0.0.1:3000/home/change').then(res=>{
            this.change=res.data;
           })
        },
        getul(){  //让ul向上位移
         var ul=document.querySelector('.app-home .news ul');
          var x=0;
          setInterval(function(){
           x+=1.5;
           if(x>6) x=0;
            ul.style.top=`-${x}rem`;
          },1000)
        },
        link(){//跳转
           this.$router.push('/hello')
        },
        getcontent(){
           this.$axios.get('http://127.0.0.1:3000/home/content').then(res=>{
            this.content=res.data;
           })
        },
        getTime(){
          var d=new Date();
          var h=d.getHours();
          var n=new Date(d);
          var end=n.setHours(n.getHours()+1,0,0);
  
          setInterval(()=>{
                var begin=new Date();
               var last= end-begin;
               var z=parseInt(last/1000)
               var m=parseInt(last/60000)
               var s=z%60
            this.date.last=`0:${m}:${s}`;
          },1000)
          this.date.h=h;
        },
        getsou(){
         this.$axios.get('http://127.0.0.1:3000/home/st').then((res)=>{
              this.tu=res.data;
               })
        },
        getstore(){
            this.$axios.get('http://127.0.0.1:3000/home/store').then(res=>{
              //  console.log(res);
               this.store=res.data;
            })

        },
        login(){
          this.$router.push('/login')
        },
        scroll(){
          window.onscroll=function(){
            var header=document.getElementsByClassName('header');
            var img=document.getElementsByClassName('top')[0];
            var scrollTop=document.body.scrollTop||document.documentElement.scrollTop;
            if(scrollTop==0){
                // header.style.background='';
                img.style.display='none'
            }else{
              //  header.style.background='red';
               img.style.display='block'
            }
          }
        },
        top(){
          document.documentElement.scrollTop=0;
        },
        //判断登录
        islogin(){
          var val=sessionStorage.getItem('name')
          if(val==null){
            this.islog=0;
          }else{
           this.islog=1;
           this.logname=val;
          }
        },
        shop_car(){
          var val=sessionStorage.getItem('name');
          if(val==null){
            Toast('请先登录')
            return;
          }else{
            this.$router.push('/e_chart');
          }
          
        }
      },
      mounted() {
        this.getul();
        this.getTime();
        this.scroll();
        this.islogin()
      },
   }
</script>
<style>
  .app-home .swipe{
    background:#ccc;
    height:14rem;
  }
 .app-home .swipe img{
   width:100%;
   height:100%;
 } 
 .app-home .header{
   position:fixed;
   top:0;
   left:0;
   z-index:2;
   display:flex;
   flex-flow:row nowrap;
   width:100%;
   height:2.9rem;
   justify-content:center;
   align-items:center;
   box-sizing:content-box;
 }
 .app-home .header span.first{
     width:10%;
     height:2rem;
 }
 .app-home .header input{
   width:60%;
   border-radius:3rem;
   height:2.3rem;
   margin:0;
 }
 .app-home .header .first{
   background:url(../assets/load.png) no-repeat;
   background-size: 80%;
   background-position:0rem 0.3rem;
   height:2rem;
   margin-right:0.5rem;
 }
 .app-home .header span:last-child{
  font-size:1rem;
  color:#fff;
  line-height:2rem;
   margin-left:0.5rem;
 }
 .app-home>img{
   width:100%;
   border-radius:2rem 2rem 0 0;
 }
 .app-home .nav{
   width:100%;
   display: flex; 
   justify-content:center;
   flex-flow: row wrap;
 }
 .app-home .nav a{
   width:5rem;
   box-sizing: border-box;
   display: flex;
   flex-direction:column;
   align-items:center;
   color:#000;
   font-size:1rem;
   padding:0.5rem 0;
 }
 .app-home .nav a >img{
   width:2rem;
   height:2rem;
 }
  .app-home .news{
    display: flex;
    margin-top:0.3rem;
    padding:0 1.5rem;
    font-size:1.5rem; 
    color: #000;
    height:2rem;
    overflow: hidden;
    justify-content: space-between
  }
 .app-home .news ul{
   width:13rem;
   margin:0 ;padding:0;
   list-style: none; 
   position: relative;
 }
 .app-home .news ul>li{
   font-size: 0.5rem;
    height:1.5rem;
    width:12rem;
    overflow: hidden;
    line-height: 2rem;
 }
 .app-home>nav{
   position:fixed;
   bottom:0;
 }
 .app-home>nav img{
   position:absolute;
   bottom:0;
   left:50%;
   margin-left:-2.5rem;
   width:5rem;
   height:4.5rem;
 }
 .app-home .content{
   display: flex;
   flex-flow:row nowrap;
 }
 .app-home .content img:first-child{
   width:50%;
 }
 .app-home .content img {
   width:25%;
   height:10rem;
 }
 .app-home .sou .first {
   text-align:justify;
 }
 .app-home >.sou strong{
   margin-left:0;
   color:red;
 }
  .app-home .sou .first>span{
    font-weight: bold;
  }
 .app-home .sou .first>span.more{
   color:red !important;
 } 
 .app-home .sou input{
   width:11rem;
   border:0;
   outline:0;
   margin: 0;
   background: #EFEFF4;
 }
  .app-home .sou ul{
    list-style: none;
    margin:0;
    padding:0;
    height:10rem;
    width:57rem;
    background: #fff;
  }
   .app-home .sou ul>li{
     float:left;
     width:8rem;
     height:10rem;

}
.app-home .sou ul>li>p{
  margin:0;
  padding:0;
}

.app-home .sou ul>li .new{
  color:red;
  font-size:2rem;
}
.app-home .sou ul>li .old{
 text-decoration: line-through;
}
 .app-home .sou ul>li>img{
    width:100%;height:65%;
}
.app-home .sou .two{
  overflow:auto;
}
.app-home .nav img{
  width:100%;
  height:100%;
}
.app-home .store ul{
  list-style: none;
  padding:0;
  margin:0;
  display: flex;
  flex-flow: row wrap;
  justify-content:space-between;
  background: #fff;
}
.app-home .store ul li{
  margin:1rem 0;
  display: flex;
  width:50%;
  justify-content:space-between;
}
.app-home .store ul li img{
  width:40%;
  height:100%;
}
.app-home .store ul li p{
  color:#D663E1;
}
.app-home .store_two ul{
  list-style: none;
  padding:0;
  margin:0;
  display: flex;
  flex-flow: row wrap;
  justify-content:space-around;
  background: #fff;
}
.app-home .store_two ul li{
  width:25%;
}
.app-home .store_two ul li img{
  width:90%;
  height:60%;
}
.app-home .store_two ul li p{
  color:#D663E1;
}
.app-home .top{
  position:fixed;
  bottom:5rem;
  right:2rem;
  width:10%;
}
.app-home .foot .first{
  list-style: none;
  margin:0;
  padding:0;
  display:flex;
   padding:1rem 0;
}
.app-home .foot .first li{
  width:25%;
  color:#B2B3B5;
}
.app-home .foot .first li:not(:first-child){
  border-left:1px solid #B2B3B5; 
}
.app-home .two {
  list-style: none;
  margin:0;
  padding:0;
  display:flex;
  justify-content:space-around;
}
.app-home .two li{
  width:20%;
}
.app-home .two li img{
  width:100%;
  height:100%;
}
</style>
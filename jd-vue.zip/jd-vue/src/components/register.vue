<template>
    <div class='app-register'>
      <mt-header title="京东注册">
        <router-link to="/home" slot="left">
         <mt-button icon="back"></mt-button>
         </router-link>
      </mt-header>
      <hr>
    <form action="">
        <p>
             用户姓名：<input type="text" v-model="name" @blur='sure()' placeholder="请输入用户名" autofocus>
        </p>
         <p>
            用户密码：<input type="password" v-model='pwd' placeholder="请输入密码">
         </p>
         <p>
            重复密码：<input type="password" v-model='cpwd' @blur='copy()' placeholder="请输入相同的密码">
         </p>
       <input type="submit" value='提交' @click.prevent='submit()' :disabled='disabled' ><input type="reset" vlue='重置' @click.prevent="reset()">
     </form>
    </div>
</template>
<script>
import { Toast } from 'mint-ui';
    export default({
      data(){
          return{
           name:'',
           pwd:'',
           cpwd:'',
           disabled:true
          }
      },
      methods:{
          copy(){
              if(this.name==null||this.pwd==null||this.cpwd==null){
                 Toast('请将信息填写完整');
                 return;
              }
              if(this.pwd==this.cpwd){
                  this.disabled=false;
              }else{
                    Toast('密码输入不一至');
                    return;
              }
          },
          sure(){
              if(this.name==''){
                  Toast('请输入用户名')
                  return;
              }
              this.$axios.get('http://127.0.0.1:3000/user/sure',{
                  params:{
                      name:this.name
                  }
              }).then(res=>{
                  if(res.data[0].num>0){
                      Toast('用户名已经存在')
                  }
              })
          },
          reset(){
              this.disabled=true;
              this.name='';
              this.pwd='';
              this.cpwd='';
          },
          submit(){

              this.$axios.post('http://127.0.0.1:3000/user/submit',this.qs.stringify({
                    name:this.name,
                    pwd:this.pwd
              })).then(res=>{
                  if(res.data.msg==1){
                      Toast('恭喜您！ 注册成功')
                      this.$router.push('/login')
                  }else{
                      Toast('对不起！ 请重新注册')
                  }
              })
          }

      },
     mounted(){

     }

    })
</script>
<style>
      .app-register{
       background: #EFEFF4;
    }
     .app-register .mint-header{
         background: #EFEFF4;
        color:black;
        font-size: 1.2rem;
    }
    .app-register form{
        margin-top:4rem;
    }
    .app-register form p>input{
        width:70%;
    }
</style>
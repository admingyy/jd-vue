import Vue from 'vue'
import Router from 'vue-router'
import Home from '../components/home.vue'
import Hello from '../components/HelloWorld.vue'
import Login from '../components/login.vue'
import Register from '../components/register.vue'
import Family from '../components/product/family.vue'
import Mobile from '../components/product/mobile.vue'
import Computer from '../components/product/computer.vue'
import Null from '../components/product/null.vue'
import Product_info from '../components/product/product_info.vue'
import Detail from '../components/product/detail.vue'
import Checkout from '../components/checkout.vue'
import E_chart from '../components/product/e_chart.vue'
Vue.use(Router)

export default new Router({
  routes: [
    { path:'/home',component:Home},
    { path:'/hello',component:Hello},
    { path:'/login',component:Login},
    { path:'/register',component:Register},
    { path:'/checkout',component:Checkout},
    { path:'/family',component:Family,children:[
      { path:'/family/',component:Mobile},
      { path:'/family/mobile',component:Mobile},
      { path:'/family/computer',component:Computer},
      { path:'/family/null',component:Null},
    ]},
    { path:'/product_info',component:Product_info},
    { path:'/detail',component:Detail},
    { path:'/e_chart',component:E_chart},
  ]
})

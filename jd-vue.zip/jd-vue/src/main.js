// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router/router'
import Axios from 'axios';
import Qs  from 'qs';
                
import'mint-ui/lib/style.css'
Vue.config.productionTip = false;
//axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
//axios.defaults.baseURL = 'http://localhost:7878/zkview';
Vue.prototype.$axios=Axios;          //调用axios
Vue.prototype.qs=Qs;

import Mintui from  'mint-ui';
Vue.use(Mintui);     //mint-ui


import VueResource from 'vue-resource' //----因为这个加载所以this.$http.get才有 
Vue.use(VueResource)//注册
Vue.http.options.root='http://127.0.0.1:3000/';


/* eslint-disable no-new */
import './lib/mui/css/mui.css'  //mui
import './lib/mui/css/icons-extra.css'

//vueX
import Vuex from 'vuex';
Vue.use(Vuex);
var store=new Vuex.Store({
  state:{count:0},//购物车商品数量
  mutations:{
    increment(state,c){
      state.count+=c;  //修改 增加
    },
    substract(state){
      state.count-- //修改 减少
    }
  },
  getters:{
    optCount:function(state){    //获取 
      return state.count;
    }
  }
})

new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
